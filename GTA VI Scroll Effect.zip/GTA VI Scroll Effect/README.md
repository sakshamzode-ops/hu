# GTA VI - Landing page

Welcome!

Disclaimer: This project is a fan-made clone of the official Grand Theft Auto VI website. I am not affiliated with Rockstar Games, Take-Two Interactive, or any of their subsidiaries. All images and content used in this project are the property of Rockstar Games and were sourced from https://www.rockstargames.com/VI. This project is for educational and non-commercial purposes only.


This website is build with React and nord

so dont forget to install react and nord and libraries
